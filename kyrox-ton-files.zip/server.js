/**
 * KYROX TON — single backend file
 * Render Web Service:
 *   Build command: npm install pg
 *   Start command: node server.js
 *
 * Required Render environment variables:
 *   DATABASE_URL       Render PostgreSQL internal connection string
 *   BOT_TOKEN          Telegram bot token (secret)
 *   APP_SECRET         Random 32+ character secret used to encrypt PT Exchange key
 *   BOT_USERNAME       Telegram bot username without @
 *   ADMIN_ID           8243824380
 *
 * Optional:
 *   PTEXCHANGE_API_URL https://ptexchange-api.vercel.app
 *   PORT               supplied by Render
 */
"use strict";

const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { URL } = require("node:url");
const { Pool } = require("pg");

const PORT = Number(process.env.PORT || 3000);
const ADMIN_ID = String(process.env.ADMIN_ID || "8243824380");
const BOT_TOKEN = process.env.BOT_TOKEN || "";
const BOT_USERNAME = (process.env.BOT_USERNAME || "").replace(/^@/, "");
const APP_SECRET = process.env.APP_SECRET || "";
const PT_BASE = (process.env.PTEXCHANGE_API_URL || "https://ptexchange-api.vercel.app").replace(/\/+$/, "");

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required. Add a Render PostgreSQL database.");
if (!BOT_TOKEN) throw new Error("BOT_TOKEN is required. Add your Telegram bot token as a Render secret.");
if (APP_SECRET.length < 32) throw new Error("APP_SECRET must be at least 32 characters.");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL.includes("localhost") ? false : { rejectUnauthorized: false },
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

const HTML = fs.readFileSync(path.join(__dirname, "index.html"));

function send(res, status, data, headers = {}) {
  const body = Buffer.from(JSON.stringify(data));
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": body.length,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    ...headers
  });
  res.end(body);
}
function fail(res, status, message) { return send(res, status, { ok: false, error: message }); }
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function verifyTelegramInitData(initData) {
  if (!initData) throw new Error("Open KYROX TON inside Telegram to continue.");
  const params = new URLSearchParams(initData);
  const receivedHash = params.get("hash");
  if (!receivedHash) throw new Error("Invalid Telegram authentication data.");
  params.delete("hash");
  params.delete("signature");
  const entries = [...params.entries()].sort(([a], [b]) => a.localeCompare(b));
  const checkString = entries.map(([k, v]) => `${k}=${v}`).join("\n");
  const secretKey = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  const calculated = crypto.createHmac("sha256", secretKey).update(checkString).digest("hex");
  if (!safeEqual(calculated, receivedHash)) throw new Error("Telegram authentication failed.");
  const authDate = Number(params.get("auth_date") || 0);
  if (!authDate || Math.floor(Date.now() / 1000) - authDate > 86400 || authDate > Math.floor(Date.now()/1000) + 60) {
    throw new Error("Telegram session expired. Close and reopen the mini app.");
  }
  let user;
  try { user = JSON.parse(params.get("user") || "{}"); } catch { throw new Error("Invalid Telegram user data."); }
  if (!user.id) throw new Error("Telegram user ID is missing.");
  return {
    id: String(user.id),
    first_name: String(user.first_name || "User").slice(0, 80),
    last_name: String(user.last_name || "").slice(0, 80),
    username: String(user.username || "").slice(0, 64),
    start_param: String(params.get("start_param") || "")
  };
}
function encryptSecret(plain) {
  const key = crypto.createHash("sha256").update(APP_SECRET).digest();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  return [iv.toString("base64"), cipher.getAuthTag().toString("base64"), encrypted.toString("base64")].join(".");
}
function decryptSecret(value) {
  const [ivB64, tagB64, dataB64] = String(value || "").split(".");
  if (!ivB64 || !tagB64 || !dataB64) throw new Error("Payment key is not configured correctly.");
  const key = crypto.createHash("sha256").update(APP_SECRET).digest();
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(ivB64, "base64"));
  decipher.setAuthTag(Buffer.from(tagB64, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, "base64")), decipher.final()]).toString("utf8");
}
async function readBody(req) {
  let raw = "";
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 100000) throw new Error("Request is too large.");
  }
  if (!raw) return {};
  try { return JSON.parse(raw); } catch { throw new Error("Invalid JSON request."); }
}
function num(v) { const n = Number(v); return Number.isFinite(n) ? n : NaN; }
function txTitle(type) {
  return ({ referral: "Referral reward", daily: "Daily reward", task: "Task reward", withdrawal: "Withdrawal request", adjustment: "Admin balance adjustment" })[type] || type;
}
async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGINT PRIMARY KEY, first_name TEXT NOT NULL DEFAULT 'User',
      username TEXT NOT NULL DEFAULT '', balance NUMERIC(24,8) NOT NULL DEFAULT 0,
      wallet TEXT NOT NULL DEFAULT '', referred_by BIGINT, referrals INTEGER NOT NULL DEFAULT 0,
      tasks_completed INTEGER NOT NULL DEFAULT 0, last_daily DATE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS channels (id BIGSERIAL PRIMARY KEY, channel TEXT NOT NULL, url TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS tasks (
      id BIGSERIAL PRIMARY KEY, title TEXT NOT NULL, reward NUMERIC(24,8) NOT NULL,
      url TEXT NOT NULL, active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS task_completions (
      id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id),
      task_id BIGINT NOT NULL REFERENCES tasks(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(user_id, task_id)
    );
    CREATE TABLE IF NOT EXISTS withdrawals (
      id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id),
      amount NUMERIC(24,8) NOT NULL, wallet TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
      provider_ref TEXT, admin_note TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      reviewed_at TIMESTAMPTZ
    );
    CREATE TABLE IF NOT EXISTS transactions (
      id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id),
      type TEXT NOT NULL, amount NUMERIC(24,8) NOT NULL, title TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query("INSERT INTO settings(key,value) VALUES('ref_reward','0.01'),('daily_reward','0.001'),('min_withdrawal','0.1'),('max_withdrawal','100'),('fee_percent','0'),('ton_autopay','false') ON CONFLICT(key) DO NOTHING");
}
async function getSettings() {
  const r = await pool.query("SELECT key,value FROM settings");
  return Object.fromEntries(r.rows.map(x => [x.key, x.value]));
}
async function setSetting(key, value) {
  await pool.query("INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value", [key, String(value)]);
}
async function ensureUser(user, startParam) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const existed = await client.query("SELECT id FROM users WHERE id=$1 FOR UPDATE", [user.id]);
    if (!existed.rowCount) {
      let referrer = null;
      const match = /^ref_(\d+)$/.exec(String(startParam || ""));
      if (match && match[1] !== user.id) {
        const ref = await client.query("SELECT id FROM users WHERE id=$1 FOR UPDATE", [match[1]]);
        if (ref.rowCount) referrer = match[1];
      }
      await client.query("INSERT INTO users(id,first_name,username,referred_by) VALUES($1,$2,$3,$4)", [user.id,user.first_name,user.username,referrer]);
      if (referrer) {
        const settings = await client.query("SELECT value FROM settings WHERE key='ref_reward'");
        const reward = Number(settings.rows[0]?.value || 0.01);
        await client.query("UPDATE users SET referrals=referrals+1,balance=balance+$2 WHERE id=$1", [referrer,reward]);
        await client.query("INSERT INTO transactions(user_id,type,amount,title) VALUES($1,'referral',$2,$3)", [referrer,reward,"Referral reward"]);
      }
    } else {
      await client.query("UPDATE users SET first_name=$2,username=$3 WHERE id=$1", [user.id,user.first_name,user.username]);
    }
    await client.query("COMMIT");
  } catch (e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}
async function requireUser(req) {
  const user = verifyTelegramInitData(req.headers["x-telegram-init-data"]);
  return user;
}
function isAdmin(user) { return String(user.id) === ADMIN_ID; }
async function requireAdmin(req) {
  const user = await requireUser(req);
  if (!isAdmin(user)) throw Object.assign(new Error("Admin access denied."), { status: 403 });
  return user;
}
async function recordTx(client, userId, type, amount, title) {
  await client.query("INSERT INTO transactions(user_id,type,amount,title) VALUES($1,$2,$3,$4)", [userId,type,amount,title || txTitle(type)]);
}
async function route(req, res) {
  const url = new URL(req.url, "http://localhost");
  const path = url.pathname;
  if (req.method === "GET" && path === "/health") return send(res,200,{ok:true,service:"KYROX TON"});
  if (req.method === "GET" && path === "/") {
    res.writeHead(200, {"Content-Type":"text/html; charset=utf-8","Content-Length":HTML.length,"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"});
    return res.end(HTML);
  }
  if (!path.startsWith("/api/")) return fail(res,404,"Not found.");
  let user;
  try { user = await requireUser(req); }
  catch (e) { return fail(res,401,e.message); }
  let body = {};
  if (req.method === "POST") {
    try { body = await readBody(req); } catch (e) { return fail(res,400,e.message); }
  }
  try {
    const startParam = url.searchParams.get("tgWebAppStartParam") || body.start_param || user.start_param || "";
    await ensureUser(user, startParam);
    if (req.method === "GET" && path === "/api/me") {
      const r = await pool.query("SELECT id,first_name,username,balance,wallet,referrals,tasks_completed FROM users WHERE id=$1",[user.id]);
      const recent = await pool.query("SELECT title,amount,created_at FROM transactions WHERE user_id=$1 ORDER BY id DESC LIMIT 5",[user.id]);
      return send(res,200,{ok:true,user:r.rows[0],recent:recent.rows.map(x=>({title:x.title,amount:`${Number(x.amount).toFixed(4)} TON`,date:new Date(x.created_at).toLocaleString("en-GB")}))});
    }
    if (req.method === "GET" && path === "/api/force-join") {
      const channels=await pool.query("SELECT id,channel,url FROM channels ORDER BY id ASC");
      const checked=await Promise.all(channels.rows.map(async ch=>{
        try{
          const apiUrl=`https://api.telegram.org/bot${BOT_TOKEN}/getChatMember?chat_id=${encodeURIComponent(ch.channel)}&user_id=${encodeURIComponent(user.id)}`;
          const r=await fetch(apiUrl); const d=await r.json();
          const status=d.result?.status;
          const joined=!!d.ok && (["creator","administrator","member"].includes(status) || (status==="restricted" && d.result?.is_member===true));
          return {...ch,joined};
        }catch{return {...ch,joined:false};}
      }));
      return send(res,200,{ok:true,joined:checked.every(c=>c.joined),channels:checked});
    }
    if (req.method === "GET" && path === "/api/tasks") {
      const r=await pool.query("SELECT id,title,reward,url FROM tasks WHERE active=true ORDER BY id DESC");
      return send(res,200,{ok:true,tasks:r.rows});
    }
    if (req.method === "POST" && path === "/api/tasks/complete") {
      const required=await pool.query("SELECT channel FROM channels ORDER BY id ASC");
      for(const ch of required.rows){
        const memberUrl=`https://api.telegram.org/bot${BOT_TOKEN}/getChatMember?chat_id=${encodeURIComponent(ch.channel)}&user_id=${encodeURIComponent(user.id)}`;
        const mr=await fetch(memberUrl); const md=await mr.json(); const st=md.result?.status;
        const joined=!!md.ok && (["creator","administrator","member"].includes(st) || (st==="restricted" && md.result?.is_member===true));
        if(!joined) throw new Error(`Join ${ch.channel} first, then verify membership.`);
      }
      const taskId=num(body.task_id);
      const taskCheck=await pool.query("SELECT id,title,reward,url FROM tasks WHERE id=$1 AND active=true",[taskId]);
      if(!taskCheck.rowCount) throw new Error("Task not found.");
      const taskUrl=String(taskCheck.rows[0].url||"");
      const channelMatch=/^https?:\/\/t\.me\/([A-Za-z0-9_]{5,})(?:\?.*)?$/i.exec(taskUrl);
      if(!channelMatch) throw new Error("This task link cannot be automatically verified. Ask the admin to configure a Telegram channel task.");
      const taskMemberUrl=`https://api.telegram.org/bot${BOT_TOKEN}/getChatMember?chat_id=${encodeURIComponent("@"+channelMatch[1])}&user_id=${encodeURIComponent(user.id)}`;
      const taskMemberResponse=await fetch(taskMemberUrl); const taskMemberData=await taskMemberResponse.json();
      const taskStatus=taskMemberData.result?.status;
      const taskJoined=!!taskMemberData.ok && (["creator","administrator","member"].includes(taskStatus) || (taskStatus==="restricted" && taskMemberData.result?.is_member===true));
      if(!taskJoined) throw new Error("Join the task channel first, then tap Start again.");
      const c=await pool.connect();
      try {
        await c.query("BEGIN");
        const task=await c.query("SELECT * FROM tasks WHERE id=$1 AND active=true",[taskId]);
        if(!task.rowCount) throw new Error("Task not found.");
        const inserted=await c.query("INSERT INTO task_completions(user_id,task_id) VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING id",[user.id,taskId]);
        if(!inserted.rowCount) throw new Error("You have already completed this task.");
        const reward=Number(task.rows[0].reward);
        await c.query("UPDATE users SET balance=balance+$2,tasks_completed=tasks_completed+1 WHERE id=$1",[user.id,reward]);
        await recordTx(c,user.id,"task",reward,`Task reward: ${task.rows[0].title}`);
        await c.query("COMMIT");
        return send(res,200,{ok:true,message:"Task reward credited.",open_url:task.rows[0].url});
      } catch(e){await c.query("ROLLBACK");throw e;} finally{c.release();}
    }
    if (req.method === "GET" && path === "/api/referral") {
      const s=await getSettings(); const r=await pool.query("SELECT referrals FROM users WHERE id=$1",[user.id]);
      const link=BOT_USERNAME?`https://t.me/${BOT_USERNAME}?startapp=ref_${user.id}`:"";
      return send(res,200,{ok:true,link,reward:Number(s.ref_reward||0.01),count:r.rows[0]?.referrals||0});
    }
    if (req.method === "POST" && path === "/api/daily/claim") {
      const s=await getSettings(); const reward=Number(s.daily_reward||0.001);
      const c=await pool.connect();
      try{
        await c.query("BEGIN");
        const u=await c.query("SELECT last_daily FROM users WHERE id=$1 FOR UPDATE",[user.id]);
        const today=await c.query("SELECT CURRENT_DATE AS d");
        if(u.rows[0].last_daily && String(u.rows[0].last_daily).slice(0,10)===String(today.rows[0].d).slice(0,10)) throw new Error("You have already claimed today's reward.");
        await c.query("UPDATE users SET balance=balance+$2,last_daily=CURRENT_DATE WHERE id=$1",[user.id,reward]);
        await recordTx(c,user.id,"daily",reward,"Daily reward");
        await c.query("COMMIT");
        return send(res,200,{ok:true,message:`${reward} TON daily reward credited.`});
      }catch(e){await c.query("ROLLBACK");throw e;}finally{c.release();}
    }
    if (req.method === "POST" && path === "/api/wallet") {
      const wallet=String(body.wallet||"").trim();
      if(!/^(EQ|UQ|0:)[A-Za-z0-9_-]{20,100}$/.test(wallet)) return fail(res,400,"Enter a valid TON wallet address.");
      await pool.query("UPDATE users SET wallet=$2 WHERE id=$1",[user.id,wallet]);
      return send(res,200,{ok:true,message:"TON wallet saved."});
    }
    if (req.method === "POST" && path === "/api/withdrawals") {
      const amount=num(body.amount), wallet=String(body.wallet||"").trim();
      if(!(amount>0) || !/^(EQ|UQ|0:)[A-Za-z0-9_-]{20,100}$/.test(wallet)) return fail(res,400,"Enter a valid amount and TON wallet address.");
      const s=await getSettings(), min=Number(s.min_withdrawal||0.1), max=Number(s.max_withdrawal||100);
      if(amount<min || amount>max) return fail(res,400,`Withdrawal must be between ${min} and ${max} TON.`);
      const c=await pool.connect();
      try{
        await c.query("BEGIN");
        const u=await c.query("SELECT balance FROM users WHERE id=$1 FOR UPDATE",[user.id]);
        if(Number(u.rows[0].balance)<amount) throw new Error("Insufficient balance.");
        await c.query("UPDATE users SET balance=balance-$2,wallet=$3 WHERE id=$1",[user.id,amount,wallet]);
        await c.query("INSERT INTO withdrawals(user_id,amount,wallet) VALUES($1,$2,$3)",[user.id,amount,wallet]);
        await recordTx(c,user.id,"withdrawal",-amount,"Withdrawal request (held for admin review)");
        await c.query("COMMIT");
        return send(res,200,{ok:true,message:"Withdrawal submitted for admin approval."});
      }catch(e){await c.query("ROLLBACK");throw e;}finally{c.release();}
    }
    if (req.method === "GET" && path === "/api/transactions") {
      const r=await pool.query("SELECT title,amount,created_at FROM transactions WHERE user_id=$1 ORDER BY id DESC LIMIT 100",[user.id]);
      return send(res,200,{ok:true,transactions:r.rows.map(x=>({title:x.title,amount:`${Number(x.amount).toFixed(4)} TON`,date:new Date(x.created_at).toLocaleString("en-GB")}))});
    }

    // All administrative endpoints enforce the verified Telegram ID on the server.
    if (path.startsWith("/api/admin/")) await requireAdmin(req);
    if (req.method==="POST" && path==="/api/admin/login") {
      const stats=await pool.query("SELECT (SELECT COUNT(*) FROM users)::int AS total_users,(SELECT COUNT(*) FROM withdrawals WHERE status='pending')::int AS pending_withdrawals");
      return send(res,200,{ok:true,...stats.rows[0]});
    }
    if (req.method==="POST" && path==="/api/admin/payment-settings") {
      const apiKey=String(body.api_key||"").trim();
      if(apiKey) await setSetting("pt_api_key_enc",encryptSecret(apiKey));
      await setSetting("ton_autopay",String(!!body.ton_autopay));
      const min=num(body.min_withdrawal),max=num(body.max_withdrawal),fee=num(body.fee_percent);
      if(!(min>0) || !(max>=min) || !(fee>=0 && fee<=100)) return fail(res,400,"Check minimum, maximum and fee values.");
      await setSetting("min_withdrawal",min); await setSetting("max_withdrawal",max); await setSetting("fee_percent",fee);
      return send(res,200,{ok:true,message:"Payment settings saved securely."});
    }
    if (req.method==="POST" && path==="/api/admin/payment-test") {
      const s=await getSettings();
      return send(res,200,{ok:true,message:s.pt_api_key_enc?"PT Exchange key is saved. No payment was sent by this test.":"Add and save your PT Exchange API key first."});
    }
    if (req.method==="GET" && path==="/api/admin/withdrawals") {
      const r=await pool.query("SELECT id,user_id,amount,wallet,status,created_at FROM withdrawals WHERE status='pending' ORDER BY id ASC");
      return send(res,200,{ok:true,withdrawals:r.rows});
    }
    if (req.method==="POST" && path==="/api/admin/withdrawals/review") {
      const id=num(body.id), action=String(body.action||"");
      if(!Number.isInteger(id) || !["approve","reject"].includes(action)) return fail(res,400,"Invalid withdrawal review request.");
      const c=await pool.connect();
      try{
        await c.query("BEGIN");
        const wr=await c.query("SELECT * FROM withdrawals WHERE id=$1 FOR UPDATE",[id]);
        if(!wr.rowCount || wr.rows[0].status!=="pending") throw new Error("This withdrawal is no longer pending.");
        const w=wr.rows[0];
        if(action==="reject"){
          await c.query("UPDATE withdrawals SET status='rejected',reviewed_at=NOW(),admin_note='Rejected by admin' WHERE id=$1",[id]);
          await c.query("UPDATE users SET balance=balance+$2 WHERE id=$1",[w.user_id,w.amount]);
          await recordTx(c,w.user_id,"adjustment",w.amount,"Withdrawal rejected — funds refunded");
          await c.query("COMMIT");
          return send(res,200,{ok:true,message:"Withdrawal rejected and funds refunded."});
        }
        const settings=await getSettings();
        if(String(settings.ton_autopay)==="true"){
          if(!settings.pt_api_key_enc) throw new Error("PT Exchange API key is not configured.");
          // Do not commit an approved status until provider confirms success.
          await c.query("UPDATE withdrawals SET status='processing',admin_note='PT Exchange payout in progress' WHERE id=$1",[id]);
          await c.query("COMMIT");
          const apiKey=decryptSecret(settings.pt_api_key_enc);
          const grossAmount=Number(w.amount);
          const feePercent=Number(settings.fee_percent||0);
          const amount=Number((grossAmount*(1-feePercent/100)).toFixed(8));
          if(!(amount>0)) throw new Error("Withdrawal fee leaves no payable amount.");
          const payout=await fetch(`${PT_BASE}/pay/ton`,{
            method:"POST",headers:{"Content-Type":"application/json"},
            body:JSON.stringify({api_key:apiKey,to_address:w.wallet,amount,comment:`KYROX TON withdrawal #${w.id} user ${w.user_id}`})
          });
          const raw=await payout.text(); let result={}; try{result=JSON.parse(raw)}catch{}
          const providerStatus=String(result.status||"").toLowerCase();
          const confirmed=result.success===true || result.ok===true || ["success","successful","paid","completed"].includes(providerStatus);
          if(!payout.ok || !confirmed) {
            await pool.query("UPDATE withdrawals SET status='pending',admin_note=$2 WHERE id=$1 AND status='processing'",[id,`PT Exchange response not confirmed: ${String(result.message||result.error||providerStatus||`HTTP ${payout.status}`).slice(0,180)}`]);
            throw new Error(result.message||result.error||`PT Exchange did not confirm the payout (HTTP ${payout.status}). Withdrawal returned to pending review.`);
          }
          const ref=String(result.reference||result.tx_hash||result.transaction_id||"").slice(0,250);
          await pool.query("UPDATE withdrawals SET status='paid',provider_ref=$2,reviewed_at=NOW(),admin_note='PT Exchange payout confirmed' WHERE id=$1 AND status='processing'",[id,ref]);
          return send(res,200,{ok:true,message:"PT Exchange accepted the payout request."});
        }
        await c.query("UPDATE withdrawals SET status='approved',reviewed_at=NOW(),admin_note='Approved manually by admin' WHERE id=$1",[id]);
        await c.query("COMMIT");
        return send(res,200,{ok:true,message:"Withdrawal approved. Complete the transfer manually and record it outside the app."});
      }catch(e){try{await c.query("ROLLBACK")}catch{} throw e;}finally{c.release();}
    }
    if (req.method==="GET" && path==="/api/admin/channels") {
      const r=await pool.query("SELECT id,channel,url FROM channels ORDER BY id DESC");
      return send(res,200,{ok:true,channels:r.rows});
    }
    if (req.method==="POST" && path==="/api/admin/channels") {
      const channel=String(body.channel||"").trim(), urlValue=String(body.url||"").trim();
      if(!/^@[A-Za-z0-9_]{5,}$/.test(channel) && !/^-100\d+$/.test(channel)) return fail(res,400,"Channel must be @username or a -100… channel ID. Add the bot as an admin.");
      if(!/^https:\/\/t\.me\/[A-Za-z0-9_+/-]+/.test(urlValue)) return fail(res,400,"Enter a valid https://t.me/ channel link.");
      await pool.query("INSERT INTO channels(channel,url) VALUES($1,$2)",[channel,urlValue]);
      return send(res,200,{ok:true,message:"Force-join channel added."});
    }
    if (req.method==="POST" && path==="/api/admin/channels/delete") {
      await pool.query("DELETE FROM channels WHERE id=$1",[num(body.id)]);
      return send(res,200,{ok:true,message:"Channel removed."});
    }
    if (req.method==="POST" && path==="/api/admin/tasks") {
      const title=String(body.title||"").trim(), reward=num(body.reward), taskUrl=String(body.url||"").trim();
      if(!title || !(reward>0) || !/^https:\/\//.test(taskUrl)) return fail(res,400,"Enter a task title, positive reward and HTTPS task URL.");
      await pool.query("INSERT INTO tasks(title,reward,url) VALUES($1,$2,$3)",[title,reward,taskUrl]);
      return send(res,200,{ok:true,message:"Task created."});
    }
    if (req.method==="POST" && path==="/api/admin/users/adjust") {
      const target=String(body.user_id||"").trim(), amount=num(body.amount);
      if(!/^\d+$/.test(target) || !Number.isFinite(amount) || amount===0) return fail(res,400,"Enter a valid user ID and non-zero amount.");
      const c=await pool.connect();
      try{
        await c.query("BEGIN");
        const r=await c.query("UPDATE users SET balance=balance+$2 WHERE id=$1 RETURNING id",[target,amount]);
        if(!r.rowCount) throw new Error("User not found.");
        await recordTx(c,target,"adjustment",amount,"Admin balance adjustment");
        await c.query("COMMIT");
      }catch(e){await c.query("ROLLBACK");throw e;}finally{c.release();}
      return send(res,200,{ok:true,message:"User balance updated."});
    }
    return fail(res,404,"API route not found.");
  } catch (e) {
    console.error("API error:", e.message);
    return fail(res,e.status || 400,e.message || "Request failed.");
  }
}
const server=http.createServer((req,res)=>{
  route(req,res).catch(e=>{console.error(e);if(!res.headersSent)fail(res,500,"Server error.");else res.end();});
});
initDb().then(()=>{
  server.listen(PORT,"0.0.0.0",()=>console.log(`KYROX TON listening on ${PORT}`));
}).catch(e=>{console.error("Database initialization failed:",e);process.exit(1);});
